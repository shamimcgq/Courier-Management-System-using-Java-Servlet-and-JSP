
package com.mvc.beans;

/**
 *
 * @author Shamim
 */
public class SendGoodsBean {
    
String sname, rname, sdiv, rdiv, saddress, raddress, type, sphone, rphone;
    double price,weight;

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getRname() {
        return rname;
    }

    public void setRname(String rname) {
        this.rname = rname;
    }

    public String getSdiv() {
        return sdiv;
    }

    public void setSdiv(String sdiv) {
        this.sdiv = sdiv;
    }

    public String getRdiv() {
        return rdiv;
    }

    public void setRdiv(String rdiv) {
        this.rdiv = rdiv;
    }

    public String getSaddress() {
        return saddress;
    }

    public void setSaddress(String saddress) {
        this.saddress = saddress;
    }

    public String getRaddress() {
        return raddress;
    }

    public void setRaddress(String raddress) {
        this.raddress = raddress;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSphone() {
        return sphone;
    }

    public void setSphone(String sphone) {
        this.sphone = sphone;
    }

    public String getRphone() {
        return rphone;
    }

    public void setRphone(String rphone) {
        this.rphone = rphone;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }
    
    
}
