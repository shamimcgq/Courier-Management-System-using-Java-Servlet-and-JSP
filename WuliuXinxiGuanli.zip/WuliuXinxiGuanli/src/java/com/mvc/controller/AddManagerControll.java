/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.controller;

import com.mvc.beans.AddManagerBean;
import com.mvc.dao.AddManagerDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Shamim
 */
public class AddManagerControll extends HttpServlet {

    

    //
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String BranchName,ManagerName,Phone,City, User, Pass;
            BranchName = request.getParameter("B_name");
            ManagerName = request.getParameter("Man_name");
            Phone = request.getParameter("Phone");
            City = request.getParameter("City");
            User = request.getParameter("user");
            Pass = request.getParameter("pass");
            
            AddManagerBean managerbean = new AddManagerBean();
            managerbean.setBranchName(BranchName);
            managerbean.setManagerName(ManagerName);
            managerbean.setPhone(Phone);
            managerbean.setCity(City);
            managerbean.setUser(User);
            managerbean.setPass(Pass);
            
            AddManagerDAO addmanagerdao = new AddManagerDAO();
            String Addmanager = addmanagerdao.addmanager(managerbean);
            if (Addmanager.equals("SUCCESS")){
                 request.setAttribute("Man_name", ManagerName);
            request.getRequestDispatcher("/ManagerAdmessage.jsp").forward(request, response);
            
            }
            else{
            
            request.setAttribute("errorMessage", Addmanager);
            request.getRequestDispatcher("/CreateBranch.jsp").forward(request, response);
            
            }
            
            
            
           
            
        } catch (SQLException ex) {
            Logger.getLogger(AddManagerControll.class.getName()).log(Level.SEVERE, null, ex);
        }
            
            
            
    }

    

}
