/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.controller;

import com.mvc.beans.ManagerLoginBean;
import com.mvc.dao.ManagerLoginDAO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Shamim
 */
public class ManagerLogin extends HttpServlet {

    

    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String Username = request.getParameter("username");
        String Password = request.getParameter("password");
        
        ManagerLoginBean managerloginbean = new ManagerLoginBean();
        managerloginbean.setUsername(Username);
        managerloginbean.setPassword(Password);
        
        ManagerLoginDAO manalogindao =  new ManagerLoginDAO();
        
        String LoginValidate = manalogindao.Authenticateuser(managerloginbean);
        
         if(LoginValidate.equals("Done"))
        {
            HttpSession Managersession = request.getSession();
            Managersession.setAttribute("username", Username);
            request.setAttribute("username", Username);
            request.getRequestDispatcher("/BranchControlPanel.jsp").forward(request, response);
        
        }
        else{
        request.setAttribute("errMessage", "Invalid input");
         request.getRequestDispatcher("/ManagerLogin.jsp").forward(request, response);
        
        }
        
    }

   

}
