/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.controller;

import com.mvc.beans.SendGoodsBean;
import com.mvc.dao.SendGoodsDao;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Shamim
 */
public class SendGoodsServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();

        String sname, rname, sdiv, rdiv, saddress, raddress, type, sphone, rphone, Weight;
        double Dweight, price;

        sname = request.getParameter("S_name");
        sphone = request.getParameter("S_phone");
        rname = request.getParameter("R_name");
        rphone = request.getParameter("R_phone");
        sdiv = request.getParameter("S_Div");
        rdiv = request.getParameter("R_Div");
        saddress = request.getParameter("Saddress");
        raddress = request.getParameter("Raddress");
        type = request.getParameter("G_Type");
        Weight = request.getParameter("weight");
        Dweight = Double.parseDouble(Weight);
        //Dweight =request.getParameter("weight");

        //request.setAttribute("S_name", sname);
        //request.getRequestDispatcher("/ConfirmOrder.jsp").forward(request, response);
        if (sdiv.equals(rdiv)) {
            price = Dweight * 5;

        } else {

            price = Dweight * 10;
        }

        SendGoodsBean sendgoodsbeans = new SendGoodsBean();

        sendgoodsbeans.setSname(sname);
        sendgoodsbeans.setSdiv(sdiv);
        sendgoodsbeans.setSphone(sphone);
        sendgoodsbeans.setSaddress(saddress);
        sendgoodsbeans.setRname(rname);
        sendgoodsbeans.setRphone(rphone);
        sendgoodsbeans.setRdiv(rdiv);
        sendgoodsbeans.setRaddress(raddress);
        sendgoodsbeans.setType(type);
        sendgoodsbeans.setWeight(Dweight);
        sendgoodsbeans.setPrice(price);

        SendGoodsDao sendgoodsdao = new SendGoodsDao();

        String Inserted = sendgoodsdao.sendgoods(sendgoodsbeans);

        if (Inserted.equals("SUCCESS")) {

            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/wuliuxinxi", "root", "");
                Statement st = con.createStatement();
                String query = "SELECT OrderID, SName, SDiv, RName,RDiv,Cost FROM sendgoods WHERE SPhone = '" + sphone + "' ";

                ResultSet Res = st.executeQuery(query);
                while (Res.next()) {

                    out.println("<!DOCTYPE html>");
                    out.println("<html>");
                    out.println("<head>");
                    out.println("<title>Servlet ShowOrderTaken</title>");
                    out.println("</head>");
                    out.println("<body>");
                    out.println("<h2>Sender Name: " + Res.getString(2) + "</h2>");
                    out.println("<h2>Reciever Name: " + Res.getString(4) + "</h2>");
                    out.println("<h2>Order ID: " + Res.getInt(1) + "</h2>");
                    out.println("<h2>Fee is: " + Res.getInt(6) + " TK</h2>");
                    out.println("<a href='ManagerLogin.jsp'>Back </a>");
                    out.println("</body>");
                    out.println("</html>");
                    
                    
                    

                }

            } catch (Exception e) {
                e.getMessage();
            }
        

        //request.setAttribute("sphone", sphone);
       // request.setAttribute("gtype", type);
       // request.setAttribute("charge", price);
        //request.setAttribute("saddress", saddress);
        //response.sendRedirect("/ShowOrderTaken");

    }

    
        else {

            request.setAttribute("errMessage", "Fail to make order");
        request.getRequestDispatcher("/SendGoods.jsp").forward(request, response);

    }

}

}
