/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.controller;

import com.mvc.beans.ShowOrdersBean;
import com.mvc.dao.ShowOrderDAO;
import com.mvc.util.DBConnection;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Shamim
 */
public class ShowOrderTaken extends HttpServlet {

   
        
   
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        
         PreparedStatement preparedStatement = null;

        try {
           
            Connection con =  DBConnection.createConnection();
            String query = "SELECT * FROM sendgoods ORDER BY OrderID ASC ";
            preparedStatement = con.prepareStatement(query);
            
            ResultSet Res =  preparedStatement.executeQuery(query);
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title> Show Track </title>");
            out.println("</head>");
            out.println("<body background= 'background.jpg'>");
            out.println("<div style = 'color:white; text-align: center'>");
            out.println("<h1>All Orders Detailes</h1>");
            out.println("<table align= 'center' border = '4' cellspacing='15' style = 'text-align: center' ><tr><th>Order ID</th><th>Sender Name</th>"
                    + "<th>Sender Phone</th><th>Reciever Name</th><th>Reciever Phone</th><th>Sender City</th>"
                    + "<th>Receiver City</th><th>Weight</th><th>Cost</th></tr>");

            while (Res.next()) {
                
                
                out.println("<tr> <td> " + Res.getInt(1) + "</td><td>" + Res.getString(2) + "</td>"
                        + "<td> " + Res.getString(3) + "</td><td> " + Res.getString(6) + "</td><td> " + Res.getString(7) + "</td>"
                                + "<td> " + Res.getString(4) + "</td><td> " + Res.getString(8) + "</td><td> " + Res.getString(11) + "</td><td> " + Res.getString(12) + "</td></tr>");   
               
                              
            }
            out.println("</table>");
                
                out.println("<a href='ControlPanel.jsp'>Okay </a>");
                out.println("</div>");
                out.println("</body>");
                out.println("</html>");
                preparedStatement.close();
            con.close();

        } catch (Exception e) {
            e.getMessage();
        }
       
       
       
              
        //request.getRequestDispatcher("/ShowOrders.jsp").forward(request, response);
       
    }

   

}
