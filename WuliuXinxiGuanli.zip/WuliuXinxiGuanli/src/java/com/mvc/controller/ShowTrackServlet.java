package com.mvc.controller;

import com.mvc.util.DBConnection;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Shamim
 */
public class ShowTrackServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String orderID = request.getParameter("orderid");
        int OrderID = Integer.parseInt(orderID);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        Connection con = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String time, location;

        try {

            con = DBConnection.createConnection();
            statement = con.createStatement();
            resultSet = statement.executeQuery("SELECT Time,Location,OrderID FROM track where OrderID = '" + OrderID + "'");

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title> Show Track </title>");
            out.println("</head>");
            out.println("<body background= 'background.jpg'>");
            out.println("<div style = 'color:white; text-align: center'>");
            out.println("<h1>Tracking Result</h1>");
            out.println("<table align= 'center' border = '2' cellspacing='12' style = 'text-align: center' ><tr><th>Time</th><th>Location</th></tr>");

            if (resultSet.wasNull()) {
                
                
                String message = "This Order ID Not available";
                request.setAttribute("msg", message);
                request.getRequestDispatcher("/index.jsp").forward(request, response);

                
            } else {

                while (resultSet.next()) // Until next row is present otherwise it return false
                {
                    int Oid = resultSet.getInt(3);
                   
                    String sDate = resultSet.getString(1);
                    Date date = new Date();
                    SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
                    date = ft.parse(sDate);
                    out.println("<tr> <td> " + date + "</td><td>" + resultSet.getString(2) + "</td></tr>");

                }
            }

            out.println("</table>");

            out.println("<a href='index.jsp'>Okay </a>");
            out.println("</div>");
            out.println("</body>");
            out.println("</html>");

            con.close();

        } catch (SQLException e) {

            e.printStackTrace();
        } catch (ParseException ex) {
            Logger.getLogger(ShowTrackServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
