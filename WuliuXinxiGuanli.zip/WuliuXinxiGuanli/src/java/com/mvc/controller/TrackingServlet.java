/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.controller;

import com.mvc.beans.TrackingBeans;
import com.mvc.dao.Trackingdao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Shamim
 */
public class TrackingServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String OrderID, Location;
        int IntOrderID;

        OrderID = request.getParameter("OrderID");

        Location = request.getParameter("Location");
        
        IntOrderID = Integer.parseInt(OrderID);

        TrackingBeans trackbeans = new TrackingBeans();
        trackbeans.setOrderID(IntOrderID);
        trackbeans.setLocation(Location);

        Trackingdao trackingdao = new Trackingdao();

        String Trackupdate = trackingdao.addtrack(trackbeans);

        if (Trackupdate.equals("SUCCESS")) {
            request.setAttribute("trackid", OrderID);
            request.getRequestDispatcher("/Updatedtrack.jsp").forward(request, response);
        } else {

            request.setAttribute("errorMessage", "Not Updated! Something went wrong");
            request.getRequestDispatcher("/Tracking.jsp").forward(request, response);
        }

    }

}
