
package com.mvc.dao;

import com.mvc.beans.AddManagerBean;
import com.mvc.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author Shamim
 */
public class AddManagerDAO {
    
    public String addmanager(AddManagerBean addmanagerBean) throws SQLException{
    
        String BranchName,ManagerName,Phone,City, User, Pass;
        
        BranchName = addmanagerBean.getBranchName();
        ManagerName = addmanagerBean.getManagerName();
        Phone = addmanagerBean.getPhone();
        City = addmanagerBean.getCity();
        User = addmanagerBean.getUser();
        Pass = addmanagerBean.getPass();
        
        Connection con = null;
        PreparedStatement preparedStatement = null;
        
        try
        {
            con = DBConnection.createConnection();
            String query = "insert into branch (BranchID, BranchName, ManagerName, PhoneNumber, City, user, pass) values (Null,?,?,?,?,?,?)";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, BranchName);
            preparedStatement.setString(2, ManagerName);
            preparedStatement.setString(3, Phone);
            preparedStatement.setString(4,City);
            preparedStatement.setString(5, User);
            preparedStatement.setString(6, Pass);
            
            int i = preparedStatement.executeUpdate();
            if(i!=0){
            return "SUCCESS";
                                  
            }
            preparedStatement.close();
            con.close();
        
        }
        catch(SQLException e){
            e.printStackTrace();
        
        }
        return " Oops! Something went wrong";
        
    }
    
}
