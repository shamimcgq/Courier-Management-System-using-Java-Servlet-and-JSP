/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.mvc.beans.AdminLoginBeans;
import com.mvc.util.DBConnection;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Shamim
 */
public class AdminLoginDao {

    public String AuthenticatUser(AdminLoginBeans adminLoginbean) {
        String username = adminLoginbean.getUsername();
        String password = adminLoginbean.getPassword();
        String empid = adminLoginbean.getEmpID();

        Connection con = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String DBuser = "";
        String DBPass = "";
        String EmpID = "";
        String Name = "";

        try {
            con = DBConnection.createConnection();

            statement = con.createStatement();
            resultSet = statement.executeQuery("SELECT username, password, EmpID, Name FROM admin");

            while (resultSet.next()) // Until next row is present otherwise it return false
            {
                
                DBuser = resultSet.getString("username"); //fetch the values present in database
                DBPass = resultSet.getString("password");
                EmpID = resultSet.getString("empid");
                Name = resultSet.getString("Name");
                

                if (username.equals(DBuser) && password.equals(DBPass) && empid.equals(EmpID)) {
                    return "Done"; ////If the user entered values are already present in database, which means user has already registered so I will return SUCCESS message.
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "One or more inputs are invalid";

    }

}
