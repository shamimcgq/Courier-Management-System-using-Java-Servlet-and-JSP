
package com.mvc.dao;

import com.mvc.beans.ManagerLoginBean;
import com.mvc.util.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class ManagerLoginDAO {

    public String Authenticateuser(ManagerLoginBean managerlogin) {

        String username = managerlogin.getUsername();
        String password = managerlogin.getPassword();
        
        Connection con = null;
        Statement statement = null;
        ResultSet resultSet = null;

        String BranchName = "";
        String Pass = "";
        String UserName = "";
        
        try {
            con = DBConnection.createConnection();

            statement = con.createStatement();
            resultSet = statement.executeQuery("SELECT user, pass, BranchName FROM branch");

            while (resultSet.next()) // Until next row is present otherwise it return false
            {
                
                BranchName = resultSet.getString("BranchName"); //fetch the values present in database
                Pass = resultSet.getString("pass");
                UserName = resultSet.getString("user");
                

                if (username.equals(UserName) && password.equals(Pass)) {
                    return "Done"; ////If the user entered values are already present in database, which means user has already registered so I will return SUCCESS message.
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "One or more inputs are invalid";

    }
}
