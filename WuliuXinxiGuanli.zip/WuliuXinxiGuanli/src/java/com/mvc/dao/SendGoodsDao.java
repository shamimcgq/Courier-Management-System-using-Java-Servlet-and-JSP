package com.mvc.dao;

import com.mvc.beans.SendGoodsBean;
import com.mvc.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Shamim
 */
public class SendGoodsDao {

    public String sendgoods(SendGoodsBean sendgoodsbeans) {

        String sname, rname, sdiv, rdiv, saddress, raddress, type, sphone, rphone;
        double weight, price;

        sname = sendgoodsbeans.getSname();
        rname = sendgoodsbeans.getRname();
        sdiv = sendgoodsbeans.getSdiv();
        rdiv = sendgoodsbeans.getRdiv();
        saddress = sendgoodsbeans.getSaddress();
        raddress = sendgoodsbeans.getRaddress();
        sphone = sendgoodsbeans.getSphone();
        rphone = sendgoodsbeans.getRphone();
        type = sendgoodsbeans.getType();
        weight = sendgoodsbeans.getWeight();
        price = sendgoodsbeans.getPrice();

        Connection con = null;
        //PreparedStatement preparedStatement;

        try {
            con = DBConnection.createConnection();
            Statement st = con.createStatement();

            //String query = "INSERT INTO sendgoods (SName, SPhone, SDiv, SAddress, RName, RPhone, RDiv, RAddress, P_type, Weight, Cost) VALUES (?,?,?,?,?,?,?,?,?,?,? ))";
            String query = "INSERT INTO sendgoods (SName, SPhone, SDiv, SAddress, RName, RPhone, RDiv, RAddress, P_type, Weight, Cost) VALUES ( '"+sname+"', '"+ sphone+"', '"+sdiv+"','"+saddress+"','"+rname+"','"+rphone+"','"+rdiv+"','"+raddress+"','"+type+"','"+weight+"','"+price+"')";
           st = con.prepareStatement(query);

            /*
           preparedStatement.setString(1, sname);
            preparedStatement.setString(2, sphone);
            preparedStatement.setString(3, sdiv);
            preparedStatement.setString(4, saddress);
            preparedStatement.setString(5, rname);
            preparedStatement.setString(6, rphone);
            preparedStatement.setString(7, rdiv);
            preparedStatement.setString(8, raddress);
            preparedStatement.setString(9, type);
            preparedStatement.setDouble(10, weight);
            preparedStatement.setDouble(11, price); */

            int i = st.executeUpdate(query);
            if (i != 0) {
                return "SUCCESS";

            }
            st.close();
            con.close();

        } catch (SQLException e) {
            e.printStackTrace();

        }
        
        
        
        
        
        return "Ooops, Something went wrong there!";

    }

}
