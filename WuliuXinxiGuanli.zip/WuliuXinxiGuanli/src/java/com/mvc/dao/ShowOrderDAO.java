/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.dao;

import com.mvc.beans.ShowOrdersBean;
import com.mvc.util.DBConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Shamim
 */
public class ShowOrderDAO {
    
    public void showOrder( ShowOrdersBean showbean){
        
        
         List<ShowOrdersBean> dataList = new ArrayList<ShowOrdersBean>();//ShowOrdersBean showbean = new ShowOrdersBean();
         PreparedStatement preparedStatement = null;

        try {
           
            Connection con =  DBConnection.createConnection();
            String query = "SELECT * FROM sendgoods ORDER BY OrderID ASC ";
            preparedStatement = con.prepareStatement(query);
            
            ResultSet Res =  preparedStatement.executeQuery(query);

            while (Res.next()) {
                dataList.add(new ShowOrdersBean (Res.getInt(1),Res.getString(2),Res.getString(3),
                Res.getString(4),Res.getString(5),Res.getString(6),Res.getString(7),Res.getString(8),
                 Res.getString(9), Res.getString(10),Res.getDouble(11),Res.getDouble(12)));     
                
                
               
                
                
            }
            preparedStatement.close();
            con.close();

        } catch (Exception e) {
            e.getMessage();
        }
        
       
    
    
    
    }
    
    
}
