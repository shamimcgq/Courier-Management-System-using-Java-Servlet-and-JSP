/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mvc.dao;

import com.mvc.beans.TrackingBeans;
import com.mvc.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 *
 * @author Shamim
 */
public class Trackingdao {

    public String addtrack(TrackingBeans trackbean) {

        String Location;
        int OrderID;
        OrderID = trackbean.getOrderID();
        Location = trackbean.getLocation();

        Connection con = null;
        //PreparedStatement prestatement = null;

        try {
            con = DBConnection.createConnection();
            Statement st = con.createStatement();
            String query = "insert into track(OrderID,Location) values ('"+OrderID+"', '"+ Location+"')";
            //String query = "insert into track (ID, OrderID, Time, Location) values (Null,?,?,?)";
            //prestatement = con.prepareStatement(query);
           // prestatement.setInt(1, OrderID);
            //prestatement.setTimestamp(2, getCurrentTimeStamp());
           // prestatement.setString(3, Location);

            int i = st.executeUpdate(query);
            if (i != 0) {
                return "SUCCESS";
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return "Oooppps!";

    }

    //private Timestamp getCurrentTimeStamp() {
        //java.util.Date today = new java.util.Date();
        //return new java.sql.Timestamp(today.getTime());
    //}

}
